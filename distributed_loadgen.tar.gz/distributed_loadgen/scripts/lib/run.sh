./cli.sh set-value $1 operationcount -1
./cli.sh set-value $1 memgetproportion 1.0
./cli.sh set-value $1 memsetproportion 0.0
./cli.sh set-value $1 target 0
./cli.sh set-value $1 threadcount 16
./cli.sh set-value $1 dotransactions true
./cli.sh set-value $1 memcached.address 127.0.0.1
./cli.sh set-value $1 valuelength 256
./cli.sh run $1